//
//  ContentView.swift
//  lab3
//
//  Created by Akshaykumar Ghanshyambhai Patel on 9/3/20.
//  Copyright © 2020 Akshaykumar Ghanshyambhai Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading){
            Image("html")
                .shadow(radius: /*@START_MENU_TOKEN@*/20/*@END_MENU_TOKEN@*/)
                .frame(maxWidth: .infinity)
            Text("HTML 5")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .multilineTextAlignment(.center)
                .padding(.leading, 10.0).frame(maxWidth: .infinity)
                .shadow(radius: /*@START_MENU_TOKEN@*/50/*@END_MENU_TOKEN@*/)                .frame(maxWidth: .infinity)
            }
        }
    }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
